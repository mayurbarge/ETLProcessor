package parser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

import inputsource.FileInputSource;
import inputsource.FileOutputSource;
import inputsource.InputSource;
import inputsource.OutputSource;

public class CapitalizeFilesStrategy implements ParserStrategy {
	private String inputDir;
	private String outputDir;

	public CapitalizeFilesStrategy(String inputDir, String outputDir) {
		this.inputDir = inputDir;
		this.outputDir = outputDir;
	}

	public void execute() throws Exception {
		Path source = Paths.get(inputDir);
		Path dest = Paths.get(outputDir);

		File inputDir = source.toFile();
		File outputDir = dest.toFile();

		if (!inputDir.isDirectory() || !outputDir.isDirectory()) {
			throw new Exception("Input/Output directory not valid");
		}

		File[] inputFiles = inputDir.listFiles();
		for (int i = 0; i < inputFiles.length; i++) {
			try {
				processFile(inputFiles[i], outputDir);
			} catch (Exception e) {
				throw new Exception("Error while processing file - " + inputFiles[i]);
			//	System.out.println(e.getMessage());
			}
		}

	}

	private void processFile(File inputFile, File outDir) throws Exception {
		InputSource inSource = new FileInputSource(inputFile);
		inSource.setup();
		OutputSource outSource = new FileOutputSource(
				new File(outDir.getAbsolutePath() + File.separator
						+ inputFile.getName()));

		try {
			byte[] buffer = new byte[1024];
			int bytesRead = 0;

			while ((bytesRead = inSource.read(buffer)) > 0) {

				for (int i = 0; i < bytesRead; i++) {
					byte c = buffer[i];
					if (Character.isLowerCase(c)) {
						c = (byte) Character.toUpperCase(c);
					}
					buffer[i] = c;
				}
				if(bytesRead < buffer.length) {
					outSource.write(Arrays.copyOf(buffer, bytesRead));
				} else {
					outSource.write(buffer);
				}
			}
		} finally {
			inSource.close();
			outSource.close();
		}

	}

	void cleanup() {
	}
}
