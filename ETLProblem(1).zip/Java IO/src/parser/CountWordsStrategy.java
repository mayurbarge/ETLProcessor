package parser;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class CountWordsStrategy implements ParserStrategy {
	private String inputDir;
	private String outputDir;

	public CountWordsStrategy(String inputDir, String ouputDir) {
		this.inputDir = inputDir;
		this.outputDir = ouputDir;
	}

	public void execute() throws Exception {
		Path source = Paths.get(inputDir);
		Path dest = Paths.get(outputDir);

		File inputDir = source.toFile();
		File outputDir = dest.toFile();

		if (!inputDir.isDirectory() || !outputDir.isDirectory()) {
			throw new Exception("Input/Output directory not valid");
		}

		File[] inputFiles = inputDir.listFiles();
		for (int i = 0; i < inputFiles.length; i++) {
			try {
				processFile(inputFiles[i], outputDir);
			} catch (Exception e) {
				throw new Exception("Error while processing file - " + inputFiles[i]);
			}
		}
	}

	private void processFile(File inputFile, File outDir) throws Exception {

		BufferedInputStream in = new BufferedInputStream(new FileInputStream(
				inputFile));
		BufferedOutputStream out = new BufferedOutputStream(
				new FileOutputStream(new File(outDir.getAbsolutePath()
						+ File.separator + inputFile.getName())));
		try {
			Scanner sc = new Scanner(new FileInputStream(inputFile));
			sc.useDelimiter("[^a-zA-Z]");

			HashMap<String, Integer> map = new HashMap<String, Integer>();

			while (sc.hasNext()) {
				String token = sc.next();
				if (!map.containsKey(token)) {
					map.put(token, 1);
					continue;
				}
				Integer currentCount = map.get(token);
				map.put(token, currentCount + 1);
			}

			Set<String> keys = map.keySet();

			for (String string : keys) {
				out.write(new String(string + " -> " + map.get(string) + System.getProperty("line.separator")).getBytes());
			}

		} finally {
			in.close();
			out.close();
		}
	}

}
