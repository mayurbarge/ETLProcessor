package parser;

public interface ParserStrategy {
	public abstract void execute() throws Exception ;
}
