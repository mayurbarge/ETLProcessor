package main;

import parser.CountWordsStrategy;
import parser.ParserStrategy;

public class CountWords {

	public static void main(String[] args) throws Exception {
		ParserStrategy parser = new CountWordsStrategy(args[0], args[1]);
		//ParserStrategy parser = new CountWordsStrategy("c:/test/in", "c:/test/out");
		parser.execute();
	}

}
