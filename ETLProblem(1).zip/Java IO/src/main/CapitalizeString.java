package main;

import parser.CapitalizeFilesStrategy;
import parser.ParserStrategy;

public class CapitalizeString {
	public static void main(String[] args) throws Exception {		
		//ParserStrategy parser = new CapitalizeFilesStrategy("c:/test/in", "c:/test/out");
		ParserStrategy parser = new CapitalizeFilesStrategy(args[0], args[1]);
		parser.execute();
	}
}
