package inputsource;

public abstract class OutputSource {
	public abstract void setup();
	public abstract void write(byte[] data) throws Exception;
	public abstract void close() throws Exception;
}