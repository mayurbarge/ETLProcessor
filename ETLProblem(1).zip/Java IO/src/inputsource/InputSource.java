package inputsource;

public abstract class InputSource {
	public abstract void setup() throws Exception;
	public abstract int read(byte[] b) throws Exception;
	public abstract void close() throws Exception;
}