package inputsource;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.BufferOverflowException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class FileOutputSource extends OutputSource {
	RandomAccessFile out;
	FileChannel outChannel;
	MappedByteBuffer obuffer;

	public FileOutputSource(File file) throws IOException {
		out = new RandomAccessFile(file, "rw");
		outChannel = out.getChannel();
		obuffer = outChannel.map(FileChannel.MapMode.READ_WRITE, 0, 512);
	}

	public void setup() { obuffer.flip();}

	public void write(byte[] data) throws IOException {
			
		obuffer.put(data);
		return ;
	}

	private void writeContents() throws IOException {
		
	//	outChannel.write(obuffer);
		
	}

	public void close() throws IOException {
		writeContents();
		obuffer.clear();
		outChannel.close();
		out.close();
	}

}