package inputsource;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class FileInputSource extends InputSource {
	FileInputStream in;
	FileChannel inChannel;
	ByteBuffer bbuffer;

	public FileInputSource(File file) throws FileNotFoundException {
		in = new FileInputStream(file);
		inChannel = in.getChannel();
		bbuffer = ByteBuffer.allocateDirect(1024);
	}

	public int read(byte[] buffer) throws IOException {

		int i = 0;
		for (i = 0; i < buffer.length; i++) {
			try {
				buffer[i] = bbuffer.get();
			} catch (BufferUnderflowException e) {
			/*	bbuffer.clear();
				inChannel.read(bbuffer);
				bbuffer.flip();*/
				return i;
			}
		}

		return i;
	}

	public void close() throws IOException {
		inChannel.close();
		in.close();
	}

	public void setup() throws IOException {
		inChannel.read(bbuffer);
		bbuffer.flip();
	}

}